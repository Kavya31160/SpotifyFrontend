package com.SpotifyApp.wishlist.WishlistService.filter;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

@Configuration
@SecurityScheme(name = "Bearer Authentication", bearerFormat = "JWT", scheme = "bearer", type = SecuritySchemeType.HTTP)
public class WebSecurityConfiguration {
}
