package com.SpotifyApp.wishlist.WishlistService.service;


import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;


public interface UserWishlistService {
	
	UserWishlist addTrack(UserWishlist wishlist);	
	String  removeTrack(Long id, String trackId);
	UserWishlist findByWishlistId(Long id);
	


}
