package com.SpotifyApp.wishlist.WishlistService.exception;

public class UserNotFoundException extends RuntimeException{
	public UserNotFoundException(String message) {
        super(message);
    }

}
