package com.SpotifyApp.wishlist.WishlistService.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Track {
	@Id
	private String trackId;
	private String trackName;
	private String trackUrl;

	public String getTrackId() {
		return trackId;
	}

	public void setTrackId(String trackId) {
		this.trackId = trackId;
	}

	public String getTrackName() {
		return trackName;
	}

	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}

	public String getTrackUrl() {
		return trackUrl;
	}

	public void setTrackUrl(String trackUrl) {
		this.trackUrl = trackUrl;
	}

	public List<UserWishlist> getWishlists() {
		return wishlists;
	}

	public void setWishlists(List<UserWishlist> wishlists) {
		this.wishlists = wishlists;
	}

	@ManyToMany(mappedBy = "tracks")
	@JsonIgnore 
	private List<UserWishlist> wishlists;

}
