package com.SpotifyApp.wishlist.WishlistService.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;
import com.SpotifyApp.wishlist.WishlistService.exception.UserNotFoundException;
import com.SpotifyApp.wishlist.WishlistService.repository.UserWishlistRepo;

@Service
public class UserWishlistServiceImpl implements UserWishlistService {
	private final UserWishlistRepo userWishlistRepo;

	@Autowired
	public UserWishlistServiceImpl(UserWishlistRepo userWishlistRepo) {
		this.userWishlistRepo = userWishlistRepo;
	}

	@Override
	public UserWishlist addTrack(UserWishlist wishlist) {
		Optional<UserWishlist> wishlistEntity = userWishlistRepo.findById(wishlist.getWishlistId());
		if (wishlistEntity.isPresent()) {
			wishlistEntity.get().getTracks().addAll(wishlist.getTracks());
			userWishlistRepo.save(wishlistEntity.get());
			return wishlist;
		} else {
			return userWishlistRepo.save(wishlist);
		}
	}

	@Override
	public UserWishlist findByWishlistId(Long wishlistId) {

		Optional<UserWishlist> wishlist1 = userWishlistRepo.findById(wishlistId);
		if (wishlist1.isPresent()) {
			UserWishlist userWishlist = wishlist1.get();
			return userWishlist;
		} else {
			throw new UserNotFoundException("Did not find Track");
		}
	}

	@Override
	public String removeTrack(Long wishlistId, String trackId) {
		Optional<UserWishlist> wishlistEntity = userWishlistRepo.findById(wishlistId);
		if (wishlistEntity.isPresent()) {
			wishlistEntity.get().getTracks().removeIf(t -> t.getTrackId().equalsIgnoreCase(trackId));
		} else {
			throw new UserNotFoundException("No wishlist present with id " + wishlistId);
		}
		userWishlistRepo.save(wishlistEntity.get());
		return "removed track";

	}

}