package com.SpotifyApp.wishlist.WishlistService.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;
import com.SpotifyApp.wishlist.WishlistService.service.UserWishlistService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@SecurityRequirement(name = "Bearer Authentication")
public class UserWishlistController {

	private final UserWishlistService wishlistservice;

	public UserWishlistController(UserWishlistService wishlistservice) {
		super();
		this.wishlistservice = wishlistservice;
	}
	
	
	@PostMapping("/addTrack")
	public ResponseEntity<UserWishlist> addTrack(@RequestBody UserWishlist wishlist) {
		return new ResponseEntity<>(wishlistservice.addTrack(wishlist), HttpStatus.CREATED);
	}

	@DeleteMapping("/removeTrack")
	public ResponseEntity<String> removeTrack(@RequestParam Long wishlistId, @RequestParam String trackId) {
		return new ResponseEntity<String>(wishlistservice.removeTrack(wishlistId, trackId), HttpStatus.OK);

	}

	@GetMapping("/getTracks/{wishlistId}")
	public ResponseEntity<UserWishlist> getTrack(@PathVariable Long wishlistId) {
		return new ResponseEntity<>(wishlistservice.findByWishlistId(wishlistId), HttpStatus.OK);
	}
}
