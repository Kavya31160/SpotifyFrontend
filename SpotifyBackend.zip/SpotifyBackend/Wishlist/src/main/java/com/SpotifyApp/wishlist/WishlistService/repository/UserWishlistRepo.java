package com.SpotifyApp.wishlist.WishlistService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;

public interface UserWishlistRepo extends JpaRepository<UserWishlist,Long>{

}
