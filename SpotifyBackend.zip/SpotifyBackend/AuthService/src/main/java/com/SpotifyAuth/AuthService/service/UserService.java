package com.SpotifyAuth.AuthService.service;

import com.SpotifyAuth.AuthService.model.UserInfo;

public interface UserService {

			
			
			boolean login(String email,String password);
}
