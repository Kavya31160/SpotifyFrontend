package com.SpotifyAuth.AuthService.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpotifyAuth.AuthService.config.JwtGenerator;
import com.SpotifyAuth.AuthService.exception.UserNotFoundException;
import com.SpotifyAuth.AuthService.model.UserInfo;
import com.SpotifyAuth.AuthService.service.UserService;

@CrossOrigin
@RestController

public class AuthController {

	@Autowired
	UserService userservice;

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody UserInfo userinfo) throws UserNotFoundException {
		if (userinfo.getUseremail() == null || userinfo.getPassword() == null) {
			throw new UserNotFoundException("email and password are null");
		}
		boolean result = userservice.login(userinfo.getUseremail(), userinfo.getPassword());
		if (result == false) {
			throw new UserNotFoundException("Email / password mismatch");

		}

		if (result) {

			Map<String, String> mytoken = new JwtGenerator().generateToken(userinfo);
			return new ResponseEntity<Map>(mytoken, HttpStatus.OK);
		} else
			return new ResponseEntity("Invalid user", HttpStatus.UNAUTHORIZED);
	}

}