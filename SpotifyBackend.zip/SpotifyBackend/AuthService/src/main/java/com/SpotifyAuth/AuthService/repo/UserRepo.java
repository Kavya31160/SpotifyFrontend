package com.SpotifyAuth.AuthService.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.SpotifyAuth.AuthService.model.UserInfo;

@Repository
public interface UserRepo extends JpaRepository<UserInfo,String> {
	
	Optional<UserInfo> findByUseremailAndPassword(String email,String password);

}
