package com.stackroute.authorizeapp.Test.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.SpotifyAuth.AuthService.model.UserInfo;
import com.SpotifyAuth.AuthService.repo.UserRepo;
import com.SpotifyAuth.AuthService.service.UserServiceImpl;

public class AuthServiceTest {
	@Mock
    private UserRepo userRepo;
 
    @InjectMocks
    private UserServiceImpl userService;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
       
        @Test
            void testLoginSuccess() {
                String email = "kav@gmail.com";
                String password = "kav@123";
                UserInfo user = new UserInfo("kav@gmail.com","kav@123");
         
                when(userRepo.findByUseremailAndPassword(email, password)).thenReturn(Optional.of(user));
         
                assertTrue(userService.login(email, password));
            }
         
            @Test
            void testLoginFailure() {
                String email = "kav@gmail.com";
                String password = "kav@123";
         
                when(userRepo.findByUseremailAndPassword(email, password)).thenReturn(Optional.empty());
         
                assertFalse(userService.login(email, password));
            }
	
	
	
	
	
	
}


