package com.stackroute.authorizeapp.Test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.SpotifyAuth.AuthService.controller.AuthController;
import com.SpotifyAuth.AuthService.exception.UserNotFoundException;
import com.SpotifyAuth.AuthService.model.UserInfo;
import com.SpotifyAuth.AuthService.service.UserService;
 
class AuthControllerTest {
 
	
	@Mock
	    private UserService userService;
	 
	    @InjectMocks
	    private AuthController authController;
	 
	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }
    @Test
    void testLoginWithValidCredentials() throws UserNotFoundException {
       
        UserInfo userInfo = new UserInfo("valid@example.com", "password");
        when(userService.login(userInfo.getUseremail(), userInfo.getPassword())).thenReturn(true);
 
        
        ResponseEntity<?> responseEntity = authController.login(userInfo);
 
     
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertTrue(responseEntity.getBody() instanceof Map);
    }
 
    @Test
    void testLoginWithInvalidCredentials() throws UserNotFoundException {
    	UserInfo userInfo = new UserInfo("kav@gmail.com","kav@123");
    	 
        when(userService.login(anyString(), anyString())).thenReturn(false);
 
        assertThrows(UserNotFoundException.class, () -> authController.login(userInfo));
        
//        UserInfo userInfo = new UserInfo("invalid@example.com", "wrongpassword");
//        when(userService.login(userInfo.getUseremail(), userInfo.getPassword())).thenReturn(false);
// 
//        
//        ResponseEntity<?> responseEntity = authController.login(userInfo);
// 
//    
//        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
//        assertEquals("Invalid user", responseEntity.getBody());
    }
 
    @Test
    void testLoginWithNullCredentials() {
     
        UserInfo userInfo = new UserInfo(null, null);
 
       
        assertThrows(UserNotFoundException.class, () -> authController.login(userInfo));
    }
}

