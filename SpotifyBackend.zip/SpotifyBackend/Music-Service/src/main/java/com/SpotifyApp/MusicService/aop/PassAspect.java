package com.SpotifyApp.MusicService.aop;



import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



@Aspect
public class PassAspect {
	
	Logger mylog=LoggerFactory.getLogger(PassAspect.class);
	
	
	@Before("execution (* com.SpotifyApp.MusicService.controller.MusicController.getAllMusic(..))")
	public void beforeGetAll(JoinPoint jp)
	{
		mylog.info("Some Client is calling getAllMusic method" + jp.toString());
	}
	
	
	
}

