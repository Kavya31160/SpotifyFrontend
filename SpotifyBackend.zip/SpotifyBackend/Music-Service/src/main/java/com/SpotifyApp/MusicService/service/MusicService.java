package com.SpotifyApp.MusicService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.SpotifyApp.MusicService.Entity.Album;

public interface MusicService {
	
	public Album getMusic();
	

}
