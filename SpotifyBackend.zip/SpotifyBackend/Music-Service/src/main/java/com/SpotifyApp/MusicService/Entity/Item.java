package com.SpotifyApp.MusicService.Entity;

import java.util.List;

import lombok.Data;

@Data
public class Item {
	private  String id;
	private  String name;
	private String href;
	private List <Artist> artists;

}
