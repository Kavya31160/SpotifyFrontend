package com.SpotifyApp.MusicService.Entity;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
public class Album {
	private List<Artist> artists;
    private String id;
    private String label;
    private Track tracks;
  	
}

	