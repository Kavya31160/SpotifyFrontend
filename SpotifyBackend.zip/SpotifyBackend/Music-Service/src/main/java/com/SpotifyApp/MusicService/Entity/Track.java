package com.SpotifyApp.MusicService.Entity;

import java.util.List;

import lombok.Data;

@Data
public class Track {
	private List<Item> items;

}