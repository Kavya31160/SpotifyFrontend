package com.SpotifyApp.MusicService.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.SpotifyApp.MusicService.Entity.Album;
import com.SpotifyApp.MusicService.Entity.Token;

public class MusicServiceImplTest {
	@Mock
    private RestTemplate restTemplate;
 
    @InjectMocks
    private MusicServiceImpl musicService;
 
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    public void getTokenTest() {
       
        String tokenUrl = "http://example.com/token";
        when(restTemplate.exchange(eq(tokenUrl), eq(HttpMethod.POST), any(HttpEntity.class), eq(Token.class)))
            .thenReturn(new ResponseEntity<>(new Token(), HttpStatus.OK));
 
       
        Token token = musicService.getToken();
 
       
        assertNotNull(token);
        assertEquals("access_token", token.getAccess_token());
    }
 
    @Test
    public void getMusicTest() {
        
        String albumUrl = "http://example.com/album";
        when(restTemplate.exchange(eq(albumUrl), eq(HttpMethod.GET), any(HttpEntity.class), eq(Album.class)))
            .thenReturn(new ResponseEntity<>(new Album(), HttpStatus.OK));
 
        Album album = musicService.getMusic();
 
      
        assertNotNull(album);
        
    }

}
