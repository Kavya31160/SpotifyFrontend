package com.cts.spotify.userservice.Test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.spotify.userservice.controller.UserController;
import com.cts.spotify.userservice.entity.User;
import com.cts.spotify.userservice.exception.UserNotFoundException;
import com.cts.spotify.userservice.service.UserService;

 class UserControllerTest {
	 
		 @InjectMocks
		    private UserController userController;
		 
		    @Mock
		    private UserService userService;
		 
		    @BeforeEach
		    void setUp() {
		        MockitoAnnotations.initMocks(this);
		    }
		 
		    @Test
		    void saveUser_NewUser_SuccessfullySaved() {
		        User newUser = new User(1,9898989899L, "John", "Doe", "john.doe@example.com","password");
		        when(userService.saveUser(any(User.class))).thenReturn(newUser);
		        ResponseEntity<User> responseEntity = userController.saveUser(newUser);
		 
		        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
		        assertEquals(newUser, responseEntity.getBody());
		        verify(userService, times(1)).saveUser(any(User.class));
		    }
		 
		    @Test
		    void updateUser_ExistingUser_SuccessfullyUpdated() {
		        long userId = 1L;
		        User updatedUser = new User(userId,9898989899L, "UpdatedJohn", "UpdatedDoe", "updated.john.doe@example.com","password");
		        when(userService.updateUser(any(User.class))).thenReturn(updatedUser);
		 
		        ResponseEntity<User> responseEntity = userController.updateUser(updatedUser, userId);
		 
		        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		        assertEquals(updatedUser, responseEntity.getBody());
		        verify(userService, times(1)).updateUser(any(User.class));
		    }
		 
		    @Test
		    void deleteUser_ExistingUser_SuccessfullyDeleted() {
		        long userId = 1L;
		        User deletedUser = new User(userId, 9898989899L,"John", "Doe", "john.doe@example.com","password1");
		        when(userService.deleteUser(userId)).thenReturn(deletedUser);
		 
		        ResponseEntity<User> responseEntity = userController.deleteUser(userId);
		 
		        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		        assertEquals(deletedUser, responseEntity.getBody());
		        verify(userService, times(1)).deleteUser(userId);
		    }
		 
		    @Test
		    void deleteUser_UserNotFoundException() {
		        long userId = 1L;
		        when(userService.deleteUser(userId)).thenThrow(new UserNotFoundException("User not found"));
		 
		        assertThrows(UserNotFoundException.class, () -> userController.deleteUser(userId));
		        verify(userService, times(1)).deleteUser(userId);
		    }
		    
		    @Test
		     void findUserByUseremailTest_UserFound() {
		      
		        String userEmail = "test@example.com";
		        User expectedUser = new User(); 
		        when(userService.findByUseremail(userEmail)).thenReturn(expectedUser);
		 
		    
		        ResponseEntity<User> response = userController.findUserByUseremail(userEmail);
		 
		        
		        assertEquals(HttpStatus.OK, response.getStatusCode());
		        assertEquals(expectedUser, response.getBody());
		        verify(userService, times(1)).findByUseremail(userEmail);
		    }
		}
