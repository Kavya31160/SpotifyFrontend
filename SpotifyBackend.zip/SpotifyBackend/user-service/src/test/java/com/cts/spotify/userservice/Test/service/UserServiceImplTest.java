package com.cts.spotify.userservice.Test.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.spotify.userservice.entity.User;
import com.cts.spotify.userservice.exception.UserAlreadyExistsException;
import com.cts.spotify.userservice.exception.UserNotFoundException;
import com.cts.spotify.userservice.repository.UserRepo;
import com.cts.spotify.userservice.service.UserServiceImpl;

@SpringBootTest
class UserServiceImplTest {

	@Mock

	private UserRepo userRepo;

	@InjectMocks

	private UserServiceImpl userService;

	@Test

	void saveUserTest_UserDoesNotExist() {

		User user = new User();

		when(userRepo.findById(user.getId())).thenReturn(Optional.empty());

		when(userRepo.save(user)).thenReturn(user);

		User savedUser = userService.saveUser(user);

		assertNotNull(savedUser);

		verify(userRepo, times(1)).findById(user.getId());

		verify(userRepo, times(1)).save(user);

	}

	@Test

	void saveUserTest_UserAlreadyExists() {

		User user = new User();

		when(userRepo.findById(user.getId())).thenReturn(Optional.of(user));

		assertThrows(UserAlreadyExistsException.class, () -> userService.saveUser(user));

		verify(userRepo, times(1)).findById(user.getId());

		verify(userRepo, never()).save(any());

	}

	@Test

	void updateUserTest_UserExists() {

		User user = new User();

		when(userRepo.findById(user.getId())).thenReturn(Optional.of(user));

		when(userRepo.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

		User updatedUser = userService.updateUser(user);

		assertNotNull(updatedUser);

		verify(userRepo, times(1)).findById(user.getId());

		verify(userRepo, times(1)).save(any());

	}

	@Test

	void updateUserTest_UserNotFound() {

		User user = new User();

		when(userRepo.findById(user.getId())).thenReturn(Optional.empty());

		assertThrows(UserNotFoundException.class, () -> userService.updateUser(user));

		verify(userRepo, times(1)).findById(user.getId());

		verify(userRepo, never()).save(any());

	}

	@Test

	void deleteUserTest_UserExists() {

		Long userId = 1L;

		User user = new User();

		when(userRepo.findById(userId)).thenReturn(Optional.of(user));

		User deletedUser = userService.deleteUser(userId);

		assertNotNull(deletedUser);

		verify(userRepo, times(1)).findById(userId);

		verify(userRepo, times(1)).deleteById(userId);

	}

	@Test

	void deleteUserTest_UserNotFound() {

		Long userId = 1L;

		when(userRepo.findById(userId)).thenReturn(Optional.empty());

		assertThrows(UserNotFoundException.class, () -> userService.deleteUser(userId));

		verify(userRepo, times(1)).findById(userId);

		verify(userRepo, never()).deleteById(anyLong());

	}

	@Test

	void findByUseremailTest_UserExists() {

		String userEmail = "test@example.com";

		User user = new User();

		when(userRepo.findByUseremail(userEmail)).thenReturn(user);

		User foundUser = userService.findByUseremail(userEmail);

		assertNotNull(foundUser);

		verify(userRepo, times(1)).findByUseremail(userEmail);

	}

	@Test

	void findByUseremailTest_UserNotFound() {

		String userEmail = "nonexistent@example.com";

		when(userRepo.findByUseremail(userEmail)).thenReturn(null);

		assertNull(userService.findByUseremail(userEmail));

		verify(userRepo, times(1)).findByUseremail(userEmail);

	}

}
