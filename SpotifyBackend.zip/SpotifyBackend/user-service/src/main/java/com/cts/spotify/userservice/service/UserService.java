package com.cts.spotify.userservice.service;

import com.cts.spotify.userservice.entity.User;

  public interface UserService {
       User saveUser(User user);
       User updateUser(User user);
       User deleteUser(Long id);
       User findByUseremail(String useremail);
       
       
         
       
	}

	

