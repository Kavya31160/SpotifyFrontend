package com.cts.spotify.userservice.aop;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy   //(proxyTargetClass=true)
public class UserServiceAspectConfig {

	@Bean
	public PassAspect getaspect()
	{
		return new PassAspect();
	}
}