package com.spotifyapp.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
